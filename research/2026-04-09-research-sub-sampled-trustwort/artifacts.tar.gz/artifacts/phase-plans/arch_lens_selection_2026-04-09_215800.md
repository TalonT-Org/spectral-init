# Architecture Lens Selection — groupD Dry Run Validation

**Selected Lens:** Process Flow

**Rationale:** groupD is a sequential execution pipeline with decision gates (build, preflight, 3 trials, analysis, 4 acceptance criteria checks). Process Flow best captures the runtime behavior, step ordering, and pass/fail branching of this validation workflow.
