## Architecture Lens Selection

**Selected:** Process Flow

**Rationale:** The experiment binary is a sequential pipeline with mode-based branching (preflight/exact/subsample/sanity), a determinism gate, warmup/timed iteration loops, and JSON output — all runtime behavior and decision flow, which maps directly to the Process Flow lens.
