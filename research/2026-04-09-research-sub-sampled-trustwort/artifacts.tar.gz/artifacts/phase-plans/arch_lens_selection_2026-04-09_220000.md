# Architecture Lens Selection

**Selected Lens:** Process Flow

**Rationale:** The groupC scripts form a multi-stage execution pipeline: `run_experiment.sh` orchestrates a sequence of phases (build → preflight → determinism gate → sanity → exact → subsample trials → analysis), each with conditional abort logic. The `analyze_results.py` script implements a data processing pipeline (load → aggregate → hypothesis tests → verdicts → plots). Process Flow best captures these runtime execution stages, decision points, and abort conditions.
