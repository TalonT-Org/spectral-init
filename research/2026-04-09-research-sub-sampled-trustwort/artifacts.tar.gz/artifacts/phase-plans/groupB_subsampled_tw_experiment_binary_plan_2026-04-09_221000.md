# Implementation Plan: Experiment Binary — tw_subsample_experiment (groupB)

## Summary

Implement the full `tw_subsample_experiment.rs` binary with all four modes (`exact`, `subsample`, `sanity`, `preflight`), extending the groupA stub. The binary is the core measurement engine for the subsampled-trustworthiness research experiment: it runs trustworthiness trials with wall-clock timing, emits per-trial JSON, and validates that subsampled T(k) matches exact T(k) within tolerance.

The critical design decision is that `--mode subsample` must contain an inline copy of the per-row trustworthiness pipeline from `src/metrics.rs:trustworthiness()` (line 518), with only the outer iterator changed from `(0..n)` to the sampled `query_idx`. This requires making `dist_sq_2d_avx2_batch` public, since it is currently private and the binary (an `[[example]]`) cannot access private module items.

## Proposed Architecture

```mermaid
%%{init: {'flowchart': {'nodeSpacing': 50, 'rankSpacing': 60, 'curve': 'basis'}}}%%
flowchart TB
    classDef cli fill:#1a237e,stroke:#7986cb,stroke-width:2px,color:#fff;
    classDef stateNode fill:#004d40,stroke:#4db6ac,stroke-width:2px,color:#fff;
    classDef handler fill:#e65100,stroke:#ffb74d,stroke-width:2px,color:#fff;
    classDef phase fill:#6a1b9a,stroke:#ba68c8,stroke-width:2px,color:#fff;
    classDef newComponent fill:#2e7d32,stroke:#81c784,stroke-width:2px,color:#fff;
    classDef output fill:#00695c,stroke:#4db6ac,stroke-width:2px,color:#fff;
    classDef detector fill:#b71c1c,stroke:#ef5350,stroke-width:2px,color:#fff;
    classDef terminal fill:#1a237e,stroke:#7986cb,stroke-width:2px,color:#fff;

    START([START: cargo run --example tw_subsample_experiment])

    subgraph CLIParse ["★ CLI Parsing"]
        direction TB
        Args["★ pico_args::Arguments<br/>━━━━━━━━━━<br/>--mode, --x, --y, --k, --m<br/>--seed, --reps, --warmup<br/>--output, --data-dir"]
        ModeSwitch{"★ --mode?"}
    end

    subgraph Preflight ["Preflight Mode (from groupA)"]
        PF["run_preflight<br/>━━━━━━━━━━<br/>Validate fixture shapes"]
    end

    subgraph SharedGate ["★ Determinism Gate (non-preflight)"]
        direction TB
        Load["★ Load .npy files<br/>━━━━━━━━━━<br/>x: Array2 f64, y: Array2 f64"]
        DetCheck{"★ |T_run1 - T_run2| > 1e-6?"}
        DetFail([FATAL: non-determinism detected])
    end

    subgraph ExactMode ["★ Exact Mode"]
        direction TB
        WarmupE["★ Warmup iterations<br/>━━━━━━━━━━<br/>untimed trustworthiness calls"]
        TimedE["★ Timed iterations<br/>━━━━━━━━━━<br/>Instant::now / elapsed<br/>reps x trustworthiness(x, y, k)"]
    end

    subgraph SubsampleMode ["★ Subsample Mode"]
        direction TB
        SampleIdx["★ Sample m indices<br/>━━━━━━━━━━<br/>rand::seq::index::sample<br/>StdRng::seed_from_u64(seed)"]
        WarmupSub["★ Warmup: exact + subsample"]
        TimedExact["★ Timed exact<br/>━━━━━━━━━━<br/>trustworthiness(x, y, k)"]
        TimedSub["★ Timed subsample<br/>━━━━━━━━━━<br/>Inline per-row pipeline<br/>query_idx.into_par_iter()"]
    end

    subgraph InlinePipeline ["★ Per-Row Pipeline (inline copy)"]
        direction TB
        XDist["★ X-distance<br/>━━━━━━━━━━<br/>dist_sq_avx2_looped (d>=10)<br/>or scalar fallback"]
        XSort["★ X introselect<br/>━━━━━━━━━━<br/>select_nth_unstable_by(k)<br/>→ knn_x_set: HashSet"]
        YDist["★ Y-distance<br/>━━━━━━━━━━<br/>● dist_sq_2d_avx2_batch (d_y=2)<br/>or scalar fallback"]
        YSort["★ Y introselect<br/>━━━━━━━━━━<br/>select_nth_unstable_by(k)"]
        Penalty["★ Rank-counting penalty<br/>━━━━━━━━━━<br/>row_penalty += (rank - k)"]
    end

    subgraph SanityMode ["★ Sanity Mode"]
        direction TB
        SanityRun["★ Subsample with m=n<br/>━━━━━━━━━━<br/>All indices, no RNG"]
        SanityCheck{"★ abs_delta_t < 1e-10?"}
    end

    subgraph JSONOutput ["★ JSON Emission"]
        direction TB
        Metadata["★ Collect metadata<br/>━━━━━━━━━━<br/>cpu_model, core_count<br/>rust_version, git_commit"]
        WriteJSON["★ serde_json::to_string_pretty<br/>━━━━━━━━━━<br/>→ --output path"]
    end

    COMPLETE([COMPLETE: exit 0])

    START --> Args
    Args --> ModeSwitch
    ModeSwitch -->|"preflight"| PF
    PF --> COMPLETE
    ModeSwitch -->|"exact / subsample / sanity"| Load
    Load --> DetCheck
    DetCheck -->|"yes"| DetFail
    DetCheck -->|"no"| ModeSwitch2

    ModeSwitch2{"★ Route by mode"}

    ModeSwitch2 -->|"exact"| WarmupE
    WarmupE --> TimedE
    TimedE --> Metadata

    ModeSwitch2 -->|"subsample"| SampleIdx
    SampleIdx --> WarmupSub
    WarmupSub --> TimedExact
    TimedExact --> TimedSub
    TimedSub --> InlinePipeline
    XDist --> XSort --> YDist --> YSort --> Penalty
    Penalty -->|"sum / normalize<br/>denom = m*k*(2n-3k-1)"| Metadata

    ModeSwitch2 -->|"sanity"| SanityRun
    SanityRun --> SanityCheck
    SanityCheck -->|"pass"| Metadata
    SanityCheck -->|"fail (warning only)"| Metadata

    Metadata --> WriteJSON
    WriteJSON --> COMPLETE

    class START,COMPLETE,DetFail terminal;
    class Args cli;
    class ModeSwitch,ModeSwitch2,DetCheck,SanityCheck stateNode;
    class PF handler;
    class Load,WarmupE,TimedE,SampleIdx,WarmupSub,TimedExact,TimedSub,SanityRun newComponent;
    class XDist,XSort,YDist,YSort,Penalty newComponent;
    class Metadata,WriteJSON output;
```

**Color Legend:**
| Color | Category | Description |
|-------|----------|-------------|
| Dark Blue | Terminal/CLI | Start, end, error states; CLI arguments |
| Teal | State | Decision/routing points |
| Orange | Handler | Existing processing logic (preflight from groupA) |
| Green | New | All new components added by this plan |
| Dark Teal | Output | JSON metadata collection and file emission |

**Lens Used:** Process Flow — the plan implements a CLI binary with four distinct execution modes, a shared determinism gate, warmup/timed iteration loops, and branching control flow. The primary complexity is in the runtime behavior and state transitions between modes.

## Tests

### T1: Compilation test
```bash
cargo build --release --features cli --example tw_subsample_experiment
```
Expected: exits 0.

### T2: Exact mode produces valid JSON
```bash
cargo run --release --features cli --example tw_subsample_experiment -- \
  --mode exact --x research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_x.npy \
  --y research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_y.npy \
  --k 15 --reps 2 --warmup 1 --output /tmp/tw_exact_test.json
```
Expected: valid JSON with `mode: "exact"`, `t_exact` as f64, `wall_exact_ms` as array of 2 floats, `t_sub: null`, `wall_sub_ms: null`.

### T3: Subsample mode produces valid JSON with both metrics
```bash
cargo run --release --features cli --example tw_subsample_experiment -- \
  --mode subsample --x research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_x.npy \
  --y research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_y.npy \
  --k 15 --m 1000 --seed 42 --reps 2 --warmup 1 --output /tmp/tw_sub_test.json
```
Expected: valid JSON with `t_exact`, `t_sub`, `abs_delta_t`, both `wall_exact_ms` and `wall_sub_ms` as arrays.

### T4: Sanity acceptance criterion (P2-ACCEPT)
```bash
cargo run --release --features cli --example tw_subsample_experiment -- \
  --mode sanity --x research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_x.npy \
  --y research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_y.npy \
  --k 15 --m 10000 --output /tmp/tw_sanity_test.json
```
Expected: JSON with `abs_delta_t < 1e-10`. This is the primary acceptance criterion.

### T5: Determinism gate fires on synthetic non-deterministic input
This is validated implicitly: the determinism gate runs two identical `trustworthiness()` calls and checks `|T1 - T2| > 1e-6`. On deterministic hardware this always passes. The test is that it does NOT fail on the MERFISH fixtures (which are deterministic under Rayon's default thread pool).

### T6: Preflight still works (regression)
```bash
cargo run --release --features cli --example tw_subsample_experiment -- \
  --mode preflight --data-dir research/2026-04-10-subsampled-tw-rust/data/merfish
```
Expected: `PREFLIGHT OK`, exit 0.

## Implementation Steps

### Step 1: Make `dist_sq_2d_avx2_batch` public

**File:** `src/metrics.rs`, line 463

Change the function signature from:
```rust
unsafe fn dist_sq_2d_avx2_batch(yi: &[f64], y_flat: &[f64], n: usize, out: &mut [f64])
```
to:
```rust
#[doc(hidden)]
pub unsafe fn dist_sq_2d_avx2_batch(yi: &[f64], y_flat: &[f64], n: usize, out: &mut [f64])
```

Add `pub` and `#[doc(hidden)]` to match the convention used by `dist_sq_avx2_looped` (line 410). This is the only source-library change needed. The function is already `#[cfg(target_arch = "x86_64")]` gated, and remains `unsafe` — callers must uphold the same safety invariants documented in its `/// # Safety` block.

**Why this is necessary:** The subsample mode's per-row pipeline must be strictly identical to the library's `trustworthiness()`. The 2D AVX2 batch kernel is used for Y-distance computation when `d_y == 2`. Without pub access, the binary would have to use the scalar fallback, creating an asymmetric optimization that invalidates the experiment's "same pipeline, different iterator" premise.

### Step 2: Extend CLI parsing in the experiment binary

**File:** `research/2026-04-10-subsampled-tw-rust/scripts/tw_subsample_experiment.rs`

Replace the groupA stub's placeholder `run()` function with full CLI parsing:

```rust
fn run() -> Result<(), Box<dyn std::error::Error>> {
    let mut pargs = pico_args::Arguments::from_env();

    let mode: String = pargs.value_from_str("--mode")?;
    
    match mode.as_str() {
        "preflight" => {
            let data_dir: std::path::PathBuf = pargs.value_from_str("--data-dir")?;
            run_preflight(&data_dir)?;
        }
        "exact" | "subsample" | "sanity" => {
            let x_path: std::path::PathBuf = pargs.value_from_str("--x")?;
            let y_path: std::path::PathBuf = pargs.value_from_str("--y")?;
            let k: usize = pargs.opt_value_from_str("--k")?.unwrap_or(15);
            let m: Option<usize> = pargs.opt_value_from_str("--m")?;
            let seed: Option<u64> = pargs.opt_value_from_str("--seed")?;
            let reps: usize = pargs.opt_value_from_str("--reps")?.unwrap_or(5);
            let warmup: usize = pargs.opt_value_from_str("--warmup")?.unwrap_or(1);
            let output: std::path::PathBuf = pargs.value_from_str("--output")?;

            let x: ndarray::Array2<f64> = ndarray_npy::read_npy(&x_path)
                .map_err(|e| format!("failed to load X from {}: {e}", x_path.display()))?;
            let y: ndarray::Array2<f64> = ndarray_npy::read_npy(&y_path)
                .map_err(|e| format!("failed to load Y from {}: {e}", y_path.display()))?;

            run_experiment(&mode, x.view(), y.view(), k, m, seed, reps, warmup, &output)?;
        }
        other => return Err(format!("unknown mode: {other}").into()),
    }
    Ok(())
}
```

The `--mode` flag replaces the groupA stub's `--preflight` boolean. Preflight mode now uses `--mode preflight` instead of `--preflight` (the groupA stub's `pargs.contains("--preflight")` path is replaced). The `run_preflight` function from groupA is preserved unchanged.

### Step 3: Implement the determinism gate

Add a `determinism_gate` function that runs before any warmup/timed iterations in all non-preflight modes:

```rust
fn determinism_gate(x: ArrayView2<f64>, y: ArrayView2<f64>, k: usize) -> Result<(), Box<dyn std::error::Error>> {
    let t1 = spectral_init::metrics::trustworthiness(x, y, k);
    let t2 = spectral_init::metrics::trustworthiness(x, y, k);
    let delta = (t1 - t2).abs();
    if delta > 1e-6 {
        eprintln!(
            "FATAL: non-deterministic trustworthiness detected: T1={t1:.15}, T2={t2:.15}, |delta|={delta:.2e}"
        );
        std::process::exit(1);
    }
    Ok(())
}
```

Called at the start of `run_experiment`, before warmup, for all three modes (exact, subsample, sanity). This is P2-DETERMINISM.

### Step 4: Implement `--mode exact`

Add a `run_exact` function:

```rust
fn run_exact(
    x: ArrayView2<f64>, y: ArrayView2<f64>, k: usize,
    reps: usize, warmup: usize,
) -> (f64, Vec<f64>, f64) {
    // Warmup
    let warmup_start = Instant::now();
    for _ in 0..warmup {
        let _ = spectral_init::metrics::trustworthiness(x, y, k);
    }
    let warmup_ms = warmup_start.elapsed().as_secs_f64() * 1000.0;

    // Timed
    let mut t_exact = 0.0;
    let mut wall_ms = Vec::with_capacity(reps);
    for _ in 0..reps {
        let start = Instant::now();
        t_exact = spectral_init::metrics::trustworthiness(x, y, k);
        wall_ms.push(start.elapsed().as_secs_f64() * 1000.0);
    }
    (t_exact, wall_ms, warmup_ms)
}
```

Returns the last `t_exact` value (all reps produce the same value due to determinism), per-rep wall times in milliseconds, and warmup time.

### Step 5: Implement `--mode subsample` — inline per-row pipeline

This is the core of the binary. Add a `run_subsample_inner` function that is an inline copy of the per-row pipeline from `src/metrics.rs:trustworthiness()` (lines 518–764), with the outer iterator changed from `(0..n)` to `query_idx`.

Key differences from the library function:
1. **Outer iterator:** `query_idx.into_par_iter()` instead of `(0..n).into_par_iter()`
2. **Normalization denominator:** `m * k * (2*n - 3*k - 1)` where `m = query_idx.len()` and `n = x.nrows()` (population size)
3. **Index generation:** `rand::seq::index::sample` with `StdRng::seed_from_u64(seed)` to produce `m` unique indices from `0..n`

Everything else is identical:
- Same AVX2 runtime detection (`is_x86_feature_detected!`)
- Same contiguity assertion for X when SIMD and `d_x >= 10`
- Same four `thread_local!` scratch buffers (`COMB_DIST_X`, `COMB_INDICES`, `COMB_DIST_Y`, `COMB_INDICES_Y`)
- Same X-distance dispatch: `dist_sq_avx2_looped` for `d_x >= 10` with AVX2+FMA, scalar fallback otherwise
- Same X introselect: `select_nth_unstable_by(k, ...)` with `total_cmp` + index tiebreak
- Same `knn_x_set: HashSet<usize>` from `indices[..=k]` filtering self
- Same Y-distance dispatch: `dist_sq_2d_avx2_batch` for `d_y == 2` with AVX2, scalar fallback otherwise
- Same `dist_y[i] = f64::INFINITY` self-exclusion
- Same Y introselect
- Same rank-counting penalty loop over `indices_y[..k]`
- Same `row_penalty as f64` return per row

The function signature:

```rust
fn trustworthiness_subsample(
    x: ArrayView2<f64>, y: ArrayView2<f64>, k: usize,
    query_idx: &[usize],
) -> f64
```

The `run_subsample` mode function:

```rust
fn run_subsample(
    x: ArrayView2<f64>, y: ArrayView2<f64>, k: usize, m: usize, seed: u64,
    reps: usize, warmup: usize,
) -> (f64, f64, Vec<f64>, Vec<f64>, f64, f64) {
    use rand::SeedableRng;
    let mut rng = rand::rngs::StdRng::seed_from_u64(seed);
    let n = x.nrows();
    let idx: Vec<usize> = rand::seq::index::sample(&mut rng, n, m).into_vec();

    // Warmup exact
    let warmup_exact_start = Instant::now();
    for _ in 0..warmup {
        let _ = spectral_init::metrics::trustworthiness(x, y, k);
    }
    let warmup_exact_ms = warmup_exact_start.elapsed().as_secs_f64() * 1000.0;

    // Warmup subsample
    let warmup_sub_start = Instant::now();
    for _ in 0..warmup {
        let _ = trustworthiness_subsample(x, y, k, &idx);
    }
    let warmup_sub_ms = warmup_sub_start.elapsed().as_secs_f64() * 1000.0;

    // Timed exact
    let mut t_exact = 0.0;
    let mut wall_exact_ms = Vec::with_capacity(reps);
    for _ in 0..reps {
        let start = Instant::now();
        t_exact = spectral_init::metrics::trustworthiness(x, y, k);
        wall_exact_ms.push(start.elapsed().as_secs_f64() * 1000.0);
    }

    // Timed subsample
    let mut t_sub = 0.0;
    let mut wall_sub_ms = Vec::with_capacity(reps);
    for _ in 0..reps {
        let start = Instant::now();
        t_sub = trustworthiness_subsample(x, y, k, &idx);
        wall_sub_ms.push(start.elapsed().as_secs_f64() * 1000.0);
    }

    (t_exact, t_sub, wall_exact_ms, wall_sub_ms, warmup_exact_ms, warmup_sub_ms)
}
```

### Step 6: Implement `--mode sanity`

Sanity mode runs subsample with `m = n` (all indices `0..n`, deterministic — no RNG). It validates that the subsampled pipeline produces the same result as the library function.

```rust
fn run_sanity(
    x: ArrayView2<f64>, y: ArrayView2<f64>, k: usize, m: usize,
) -> (f64, f64, f64) {
    let n = x.nrows();
    assert_eq!(m, n, "sanity mode requires m == n (got m={m}, n={n})");
    let all_idx: Vec<usize> = (0..n).collect();
    let t_exact = spectral_init::metrics::trustworthiness(x, y, k);
    let t_sub = trustworthiness_subsample(x, y, k, &all_idx);
    let abs_delta = (t_exact - t_sub).abs();
    (t_exact, t_sub, abs_delta)
}
```

No warmup or timing needed for sanity — it is a correctness check, not a performance measurement. The `--m` parameter must be provided and must equal `n`.

### Step 7: Implement JSON output and metadata collection

Add a `collect_metadata` function and the `run_experiment` orchestrator that ties all modes together.

**Metadata collection:**
```rust
fn cpu_model() -> String {
    std::fs::read_to_string("/proc/cpuinfo")
        .ok()
        .and_then(|s| {
            s.lines()
                .find(|l| l.starts_with("model name"))
                .map(|l| l.splitn(2, ':').nth(1).unwrap_or("").trim().to_string())
        })
        .unwrap_or_else(|| "unknown".into())
}

fn core_count() -> usize {
    std::thread::available_parallelism()
        .map(|p| p.get())
        .unwrap_or(1)
}
```

`rust_version`: use `env!("RUSTC_VERSION")` if set by build script, or fall back to compile-time `rustc_version` via `env!("CARGO_PKG_RUST_VERSION")` or a simpler approach: capture `option_env!("VERGEN_RUSTC_SEMVER")` or just hardcode via a `build.rs` that runs `rustc --version`. The simplest approach: use `include_str!` or a const from build.rs. For pragmatism, use:
```rust
fn rust_version() -> String {
    option_env!("RUSTC_SEMVER").unwrap_or(env!("CARGO_PKG_RUST_VERSION")).to_string()
}
```

Actually, the simplest correct approach without adding a build.rs: read `rustc --version` output at compile time is not possible without a build script. Instead, use `std::process::Command` at runtime:

```rust
fn rust_version() -> String {
    std::process::Command::new("rustc")
        .arg("--version")
        .output()
        .ok()
        .and_then(|o| String::from_utf8(o.stdout).ok())
        .map(|s| s.trim().to_string())
        .unwrap_or_else(|| "unknown".into())
}
```

`git_commit`:
```rust
fn git_commit() -> String {
    std::process::Command::new("git")
        .args(["rev-parse", "HEAD"])
        .output()
        .ok()
        .and_then(|o| String::from_utf8(o.stdout).ok())
        .map(|s| s.trim().to_string())
        .unwrap_or_else(|| "unknown".into())
}
```

**JSON structure** — build via `serde_json::Map<String, Value>`:

```rust
let mut result = serde_json::Map::new();
result.insert("n".into(), json!(n));
result.insert("m".into(), json!(m_val));  // null for exact mode
result.insert("k".into(), json!(k));
result.insert("seed".into(), json!(seed_val));  // null for exact/sanity
result.insert("mode".into(), json!(mode));
result.insert("t_exact".into(), json!(t_exact));
result.insert("t_sub".into(), json!(t_sub_val));  // null for exact
result.insert("abs_delta_t".into(), json!(abs_delta_val));  // null for exact
result.insert("wall_exact_ms".into(), json!(wall_exact));  // array or null
result.insert("wall_sub_ms".into(), json!(wall_sub));  // array or null
result.insert("warmup_exact_ms".into(), json!(warmup_exact));
result.insert("warmup_sub_ms".into(), json!(warmup_sub));  // null for exact/sanity
result.insert("cpu_model".into(), json!(cpu_model()));
result.insert("core_count".into(), json!(core_count()));
result.insert("rust_version".into(), json!(rust_version()));
result.insert("git_commit".into(), json!(git_commit()));

let json = serde_json::to_string_pretty(&serde_json::Value::Object(result))?;
std::fs::write(&output_path, &json)?;
```

Fields not applicable to a mode are set to `serde_json::Value::Null`.

### Step 8: Wire `run_experiment` orchestrator

The `run_experiment` function dispatches by mode after the determinism gate:

```rust
fn run_experiment(
    mode: &str,
    x: ArrayView2<f64>, y: ArrayView2<f64>,
    k: usize, m: Option<usize>, seed: Option<u64>,
    reps: usize, warmup: usize,
    output: &std::path::Path,
) -> Result<(), Box<dyn std::error::Error>> {
    // P2-DETERMINISM: fatal pre-condition gate
    determinism_gate(x, y, k)?;

    let n = x.nrows();

    match mode {
        "exact" => {
            let (t_exact, wall_exact_ms, warmup_exact_ms) = run_exact(x, y, k, reps, warmup);
            emit_json(output, n, None, k, None, mode, t_exact, None, None,
                      Some(wall_exact_ms), None, warmup_exact_ms, None)?;
        }
        "subsample" => {
            let m = m.ok_or("--m is required for subsample mode")?;
            let seed = seed.ok_or("--seed is required for subsample mode")?;
            let (t_exact, t_sub, wall_exact_ms, wall_sub_ms, warmup_exact_ms, warmup_sub_ms) =
                run_subsample(x, y, k, m, seed, reps, warmup);
            let abs_delta = (t_exact - t_sub).abs();
            emit_json(output, n, Some(m), k, Some(seed), mode, t_exact, Some(t_sub),
                      Some(abs_delta), Some(wall_exact_ms), Some(wall_sub_ms),
                      warmup_exact_ms, Some(warmup_sub_ms))?;
        }
        "sanity" => {
            let m = m.ok_or("--m is required for sanity mode")?;
            let (t_exact, t_sub, abs_delta) = run_sanity(x, y, k, m);
            emit_json(output, n, Some(m), k, None, mode, t_exact, Some(t_sub),
                      Some(abs_delta), None, None, 0.0, None)?;
        }
        _ => unreachable!(),
    }
    Ok(())
}
```

### Step 9: Validate the implementation

1. **Build:** `cargo build --release --features cli --example tw_subsample_experiment`
2. **Preflight regression (T6):** Verify `--mode preflight` still works
3. **Exact mode (T2):** Run with merfish_n10k fixtures, verify JSON structure
4. **Sanity acceptance (T4, P2-ACCEPT):** Run `--mode sanity --m 10000` with merfish_n10k fixtures, verify `abs_delta_t < 1e-10`
5. **Subsample mode (T3):** Run with `--m 1000 --seed 42`, verify JSON has both exact and subsample metrics

## Verification

1. **P2-ACCEPT is the primary acceptance criterion:**
   ```bash
   cargo run --release --features cli --example tw_subsample_experiment -- \
     --mode sanity \
     --x research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_x.npy \
     --y research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_y.npy \
     --k 15 --m 10000 \
     --output /tmp/tw_sanity_acceptance.json
   ```
   Then verify: `python3 -c "import json; d=json.load(open('/tmp/tw_sanity_acceptance.json')); assert d['abs_delta_t'] < 1e-10, f'FAIL: {d[\"abs_delta_t\"]}'; print('ACCEPT')"`.

2. **Exact mode round-trip:**
   ```bash
   cargo run --release --features cli --example tw_subsample_experiment -- \
     --mode exact \
     --x research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_x.npy \
     --y research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_y.npy \
     --k 15 --reps 3 --warmup 1 \
     --output /tmp/tw_exact_roundtrip.json
   ```
   Verify: JSON has `t_exact` as a float, `wall_exact_ms` as array of 3 floats, `t_sub: null`.

3. **Subsample mode round-trip:**
   ```bash
   cargo run --release --features cli --example tw_subsample_experiment -- \
     --mode subsample \
     --x research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_x.npy \
     --y research/2026-04-10-subsampled-tw-rust/data/merfish/merfish_n10k_y.npy \
     --k 15 --m 1000 --seed 42 --reps 2 --warmup 1 \
     --output /tmp/tw_sub_roundtrip.json
   ```
   Verify: JSON has both `t_exact` and `t_sub`, `abs_delta_t` is a float, both wall arrays have 2 entries.

4. **`cargo test` passes** — the visibility change to `dist_sq_2d_avx2_batch` should not break any existing tests since it only widens access.
