# Arch Lens Selection

**Selected lens:** Development

**Rationale:** The plan primarily involves setting up project structure (new experiment directory tree), build configuration (Cargo.toml `[[example]]` entry), toolchain pinning (`rust-toolchain.toml`), and a new binary entry point — all of which are development/build tooling concerns captured by the Development lens.
