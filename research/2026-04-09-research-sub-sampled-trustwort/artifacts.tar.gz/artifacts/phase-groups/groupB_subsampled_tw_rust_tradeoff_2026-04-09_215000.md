# Experiment Binary (groupB)

## Purpose
Implement the full `tw_subsample_experiment.rs` binary with all four modes: `exact`, `subsample`, `sanity`, and `preflight` (extending the stub from groupA). This is the core measurement engine: it runs trustworthiness trials, records wall-clock timings, and emits per-trial JSON. The orchestration scripts in groupC consume this binary's output.

## Dependencies
- groupA (directory scaffold, Cargo.toml registration, preflight stub)

## Requirements
- **P2-CLI:** Implement CLI argument parsing via `pico-args` for flags: `--mode {exact|subsample|sanity|preflight}`, `--x <path>`, `--y <path>`, `--k <int>` (default 15), `--m <int>` (required for subsample/sanity), `--seed <int>` (required for subsample), `--reps <int>` (default 5), `--warmup <int>` (default 1), `--output <path>`, `--data-dir <path>` (for preflight).
- **P2-EXACT:** Implement `--mode exact`: call `spectral_init::trustworthiness(x.view(), y.view(), k)` directly (same library function, same AVX2/Rayon optimizations). Run `warmup` untimed iterations then `reps` timed iterations via `std::time::Instant`. Record `t_exact` and `wall_exact_ms` as an array of per-rep milliseconds, plus `warmup_exact_ms`.
- **P2-SUBSAMPLE:** Implement `--mode subsample` as an inline copy of the per-row pipeline from `src/metrics.rs:trustworthiness()` (line 518) with the outer iterator changed from `(0..n)` to `query_idx`. Specifically: (1) generate `query_idx` by sampling m unique indices from 0..n using `rand::seq::index::sample` with `StdRng::seed_from_u64(seed)`; (2) iterate `query_idx.into_par_iter()` with Rayon; (3) per-row: X-distances using `dist_sq_avx2_looped` kernel (d>=10) or scalar fallback; introselect for X-kNN via `select_nth_unstable_by`; Y-distances using `dist_sq_2d_avx2_batch` (d_y==2); introselect for Y-kNN; rank-counting penalty; thread-local `Vec<f64>` and `Vec<usize>` scratch buffers; (4) normalization denominator uses `m * k * (2*n - 3*k - 1)` where `n` is the population size and `m` is the sample size; (5) also compute T_exact via the library function once (with warmup); (6) record `t_exact`, `t_sub`, `abs_delta_t`, `wall_exact_ms`, `wall_sub_ms`, `warmup_exact_ms`, `warmup_sub_ms`.
- **P2-SANITY:** Implement `--mode sanity`: run subsample with m=n (all indices 0..n, deterministic — no RNG needed since all rows are selected), compare to exact. JSON includes `t_exact`, `t_sub`, `abs_delta_t`. Acceptance: `abs_delta_t < 1e-10`.
- **P2-DETERMINISM:** Before any timed trials, run 2 identical calls to `trustworthiness(x, y, k)` and compare. If `|T_run1 - T_run2| > 1e-6`, print an error message and exit with non-zero status. This is a fatal pre-condition gate, not a warning.
- **P2-JSON:** All modes emit JSON to `--output <path>` with fields: `n`, `m`, `k`, `seed`, `mode`, `t_exact`, `t_sub`, `abs_delta_t`, `wall_exact_ms` (array of 5 floats), `wall_sub_ms` (array of 5 floats), `warmup_exact_ms`, `warmup_sub_ms`, `cpu_model` (from `/proc/cpuinfo`), `core_count` (from `std::thread::available_parallelism()`), `rust_version` (from `rustc --version` or compile-time env), `git_commit`. Fields not applicable to a mode (e.g., `t_sub` in exact mode) are included as JSON `null`.
- **P2-ACCEPT:** The acceptance criterion — `--mode sanity` with merfish_n10k fixtures and `--m 10000` produces JSON with `abs_delta_t < 1e-10` — must be validated by compiling and running the binary.

## Planning Context
- `src/metrics.rs:trustworthiness()` is at line 518 — read this function carefully to copy the per-row pipeline identically (SIMD kernel selection, scratch buffer layout, rank-counting logic).
- The AVX2 kernels (`dist_sq_avx2_looped`, `dist_sq_2d_avx2_batch`) are in `src/metrics.rs` and called within the trustworthiness function — they are `pub(crate)` or `pub` and accessible to the example binary via `spectral_init::` if re-exported, otherwise the subsample loop must use the public `trustworthiness` API and the inline copy must access internal functions. Check visibility before implementing.
- The `cli` feature gates `ndarray-npy`, `pico-args`, `serde_json` — all available without new deps.
- The binary is registered as a `[[example]]` (not `[[bin]]`); build with `cargo run --release --features cli --example tw_subsample_experiment`.
- Rayon determinism check must run before the warmup in all non-preflight modes.
- The per-row pipeline in `--mode subsample` must be strictly identical to the library's — no shortcuts that could create asymmetric optimization vs. `--mode exact`.
