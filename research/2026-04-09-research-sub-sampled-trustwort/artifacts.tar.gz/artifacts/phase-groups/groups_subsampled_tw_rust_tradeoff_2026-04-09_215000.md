# Implementation Groups: Subsampled Trustworthiness Rust Tradeoff

**Date:** 2026-04-09
**Source:** /home/talon/projects/spectral-init/.autoskillit/temp/plan-experiment/experiment_plan_subsampled_tw_rust_tradeoff_2026-04-09_205451.md
**Groups:** 4

## Per-Group Files

- `groupA_subsampled_tw_rust_tradeoff_2026-04-09_215000.md`
- `groupB_subsampled_tw_rust_tradeoff_2026-04-09_215000.md`
- `groupC_subsampled_tw_rust_tradeoff_2026-04-09_215000.md`
- `groupD_subsampled_tw_rust_tradeoff_2026-04-09_215000.md`

## Manifest

`manifest_subsampled_tw_rust_tradeoff_2026-04-09_215000.json`

## Dependency Chain

groupA → groupB → groupC → groupD

(Strictly linear: each group depends on all prior groups.)

---

## Directory Scaffold, Toolchain, Environment, and Preflight (groupA)

### Purpose
Create the experiment directory tree, pin the Rust toolchain, define the Python conda environment, create data symlinks, register the experiment binary in Cargo.toml, and implement the `--preflight` mode that verifies MERFISH fixtures. This group produces the foundational scaffold that all subsequent groups build on. Nothing else can be implemented until the directory exists and the binary entry point is registered.

### Dependencies
None.

### Requirements
- **P1-DIR:** Create the full experiment directory tree at `research/2026-04-10-subsampled-tw-rust/` including subdirectories `scripts/`, `data/merfish/`, `results/raw/`, `results/analysis/`.
- **P1-TOOLCHAIN:** Create `research/2026-04-10-subsampled-tw-rust/rust-toolchain.toml` pinning `channel = "nightly-2026-03-26"` to match all prior experiment toolchain pins.
- **P1-ENV:** Create `research/2026-04-10-subsampled-tw-rust/environment.yml` with the `subsampled-tw-rust` conda env spec: Python 3.11, numpy 2.2, scipy 1.15, scikit-learn 1.6, matplotlib 3.10.
- **P1-SYMLINKS:** Create symlinks in `data/merfish/` pointing to the four pre-existing MERFISH fixtures at `research/2026-04-05-tw-perf-rerun-clean/data/merfish/`: `merfish_n10k_x.npy`, `merfish_n10k_y.npy`, `merfish_n50k_x.npy`, `merfish_n50k_y.npy`.
- **P1-CARGO:** Add a `[[example]]` entry to `Cargo.toml` registering `tw_subsample_experiment` with `path = "research/2026-04-10-subsampled-tw-rust/scripts/tw_subsample_experiment.rs"` and `required-features = ["cli"]`.
- **P1-PREFLIGHT:** Implement `--preflight` mode in the experiment binary (stub is sufficient — full binary is groupB). The preflight mode: (1) verifies each of the four fixture files exists, (2) loads each `.npy` via `ndarray_npy::read_npy` and checks shape (n10k_x: (10000,50), n10k_y: (10000,2), n50k_x: (50000,50), n50k_y: (50000,2)) and dtype f64, (3) prints `"PREFLIGHT OK"` or `"PREFLIGHT FAILED: {reason}"` and exits.

### Planning Context
- The `cli` feature already exists in `Cargo.toml` (line 24) and provides `ndarray-npy`, `pico-args`, `serde_json`, `libc` — all needed by the binary. No new dependencies required.
- Existing `[[example]]` entries in `Cargo.toml` use paths under `examples/`; the new entry uses a `research/` path following the same pattern.
- MERFISH fixture source path: `research/2026-04-05-tw-perf-rerun-clean/data/merfish/` — confirmed present with all four files.
- `research/2026-04-10-subsampled-tw-rust/` does not yet exist.
- Acceptance criterion: `cargo run --release --features cli --example tw_subsample_experiment -- --preflight --data-dir research/2026-04-10-subsampled-tw-rust/data/merfish` prints `PREFLIGHT OK`.

---

## Experiment Binary (groupB)

### Purpose
Implement the full `tw_subsample_experiment.rs` binary with all four modes: `exact`, `subsample`, `sanity`, and `preflight` (extending the stub from groupA). This is the core measurement engine: it runs trustworthiness trials, records wall-clock timings, and emits per-trial JSON. The orchestration scripts in groupC consume this binary's output.

### Dependencies
- groupA (directory scaffold, Cargo.toml registration, preflight stub)

### Requirements
- **P2-CLI:** Implement CLI argument parsing via `pico-args` for flags: `--mode {exact|subsample|sanity|preflight}`, `--x <path>`, `--y <path>`, `--k <int>` (default 15), `--m <int>` (required for subsample/sanity), `--seed <int>` (required for subsample), `--reps <int>` (default 5), `--warmup <int>` (default 1), `--output <path>`, `--data-dir <path>` (for preflight).
- **P2-EXACT:** Implement `--mode exact`: call `spectral_init::trustworthiness(x.view(), y.view(), k)` directly (same library function, same AVX2/Rayon optimizations). Run `warmup` untimed iterations then `reps` timed iterations via `std::time::Instant`. Record `t_exact` and `wall_exact_ms` as an array of per-rep milliseconds, plus `warmup_exact_ms`.
- **P2-SUBSAMPLE:** Implement `--mode subsample` as an inline copy of the per-row pipeline from `src/metrics.rs:trustworthiness()` (line 518) with the outer iterator changed from `(0..n)` to `query_idx`. Specifically: (1) generate `query_idx` by sampling m unique indices from 0..n using `rand::seq::index::sample` with `StdRng::seed_from_u64(seed)`; (2) iterate `query_idx.into_par_iter()` with Rayon; (3) per-row: X-distances using `dist_sq_avx2_looped` kernel (d>=10) or scalar fallback; introselect for X-kNN via `select_nth_unstable_by`; Y-distances using `dist_sq_2d_avx2_batch` (d_y==2); introselect for Y-kNN; rank-counting penalty; thread-local `Vec<f64>` and `Vec<usize>` scratch buffers; (4) normalization denominator uses `m * k * (2*n - 3*k - 1)` where `n` is the population size and `m` is the sample size; (5) also compute T_exact via the library function once (with warmup); (6) record `t_exact`, `t_sub`, `abs_delta_t`, `wall_exact_ms`, `wall_sub_ms`, `warmup_exact_ms`, `warmup_sub_ms`.
- **P2-SANITY:** Implement `--mode sanity`: run subsample with m=n (all indices 0..n, deterministic — no RNG needed since all rows are selected), compare to exact. JSON includes `t_exact`, `t_sub`, `abs_delta_t`. Acceptance: `abs_delta_t < 1e-10`.
- **P2-DETERMINISM:** Before any timed trials, run 2 identical calls to `trustworthiness(x, y, k)` and compare. If `|T_run1 - T_run2| > 1e-6`, print an error message and exit with non-zero status. This is a fatal pre-condition gate, not a warning.
- **P2-JSON:** All modes emit JSON to `--output <path>` with fields: `n`, `m`, `k`, `seed`, `mode`, `t_exact`, `t_sub`, `abs_delta_t`, `wall_exact_ms` (array of 5 floats), `wall_sub_ms` (array of 5 floats), `warmup_exact_ms`, `warmup_sub_ms`, `cpu_model` (from `/proc/cpuinfo`), `core_count` (from `std::thread::available_parallelism()`), `rust_version`, `git_commit`. Fields not applicable to a mode are included as JSON `null`.
- **P2-ACCEPT:** The acceptance criterion — `--mode sanity` with merfish_n10k fixtures and `--m 10000` produces JSON with `abs_delta_t < 1e-10` — must be validated by compiling and running the binary.

### Planning Context
- `src/metrics.rs:trustworthiness()` is at line 518 — read this function carefully to copy the per-row pipeline identically (SIMD kernel selection, scratch buffer layout, rank-counting logic).
- The AVX2 kernels are used within the trustworthiness function — check their visibility before implementing the inline subsample loop.
- The `cli` feature gates `ndarray-npy`, `pico-args`, `serde_json` — all available without new deps.
- Rayon determinism check must run before the warmup in all non-preflight modes.
- The per-row pipeline in `--mode subsample` must be strictly identical to the library's — no shortcuts that could create asymmetric optimization vs. `--mode exact` (per threat RT3 in the experiment plan).

---

## Orchestration and Analysis Scripts (groupC)

### Purpose
Create the three Python/shell scripts that orchestrate trial execution and evaluate hypotheses: `utils.py` (shared constants), `analyze_results.py` (aggregation, H1-H6 hypothesis testing, verdict generation, plots), and `run_experiment.sh` (shell orchestrator for the full trial matrix). This group produces a complete, runnable pipeline — after groupC, the dry run in groupD can execute.

### Dependencies
- groupA (experiment directory exists, `scripts/` subdirectory present)
- groupB (binary built and accepting all modes)

### Requirements
- **P3-UTILS:** Create `research/2026-04-10-subsampled-tw-rust/scripts/utils.py` with shared constants: `K = 15`, `SEEDS = list(range(10))`, `M_VALUES_10K = [500, 1000, 2000, 3000, 5000, 7500, 10000]`, `M_VALUES_50K = [1000, 2000, 5000, 10000, 20000, 35000, 50000]`, `PYTHON_SPEEDUP_10K = {500: 18.2, 1000: 9.1, 2000: 4.1, 5000: 1.7}`, `PYTHON_MEAN_DELTA_T_10K_M2000 = 0.00165`.
- **P3-ANALYZE:** Create `research/2026-04-10-subsampled-tw-rust/scripts/analyze_results.py` implementing: (1) load all JSON files from `results/raw/`; (2) per-(n,m) cell statistics: mean|ΔT|, max|ΔT|, std(T_sub), count, median wall times, speedup_ratio; (3) H1: one-sample t-test on |ΔT| at (n=10K, m=2000) vs threshold 0.01, one-sided α=0.025; (4) H2: per-stratum OLS speedup_ratio ~ n/m, bootstrap R² (1000 resamples), linear vs log-linear RMSE comparison; (5) H3: log-log OLS std(T_sub) ~ m, one-sided t-test on slope vs -0.3; (6) H4: compare Rust speedup ratios to PYTHON_SPEEDUP_10K, report log2(rust/python) per point; (7) H5: same as H1 at n=50K (exploratory); (8) H6: sanity JSON abs_delta_t < 1e-10 for both n values; (9) write verdicts.json with structured verdicts including INSUFFICIENT_DATA; (10) generate error_vs_m.png, speedup_vs_m.png, variance_decay.png; (11) write summary.md; (12) outlier reporting without exclusion (report-and-include protocol).
- **P3-SHELL:** Create `research/2026-04-10-subsampled-tw-rust/scripts/run_experiment.sh` orchestrating: (1) cd to project root; (2) cargo build; (3) preflight check; (4) Rayon determinism check; (5) sanity checks (n=10K m=10000, n=50K m=50000); (6) exact baselines (n=10K and n=50K, 5 reps + 1 warmup); (7) subsample trials (nested loop n/m/seed); (8) analysis script invocation via micromamba.

### Planning Context
- verdicts.json structure is specified exactly in the experiment plan (see the JSON example with H1-H6 keys) — follow it precisely.
- When fewer than required trials exist: each key still appears with `"verdict": "INSUFFICIENT_DATA"` and `"reason"` field.
- `run_experiment.sh` must map n=10000 → "n10k", n=50000 → "n50k" for fixture paths.
- Trial ordering: n=10K first, then n=50K; m ascending within each n; seeds sequential.
- Total planned trials: 144 JSON files.

---

## Dry Run Validation (groupD)

### Purpose
Execute a minimal 3-trial subset of the experiment to validate end-to-end pipeline correctness before committing to the full ~144-trial run. This group produces no new code — it executes the pipeline and verifies acceptance criteria.

### Dependencies
- groupA, groupB, groupC (all prior groups complete)

### Requirements
- **P4-DRYRUN:** Execute exactly 3 trials: (1) `(n=10K, m=2000, seed=0)` — subsample mode; (2) `(n=10K, m=10000, seed=0)` — subsample with m=n (H6 sanity check); (3) `(n=50K, m=2000, seed=0)` — tests n=50K data path. Each writes one JSON to `results/raw/`.
- **P4-ACCEPT:** Verify all four acceptance criteria: (1) all 3 JSONs written with all expected fields; (2) m=n trial (n=10K, m=10000) has `abs_delta_t < 1e-10`; (3) `analyze_results.py` produces `verdicts.json` with all 6 keys (H1-H6), most as `INSUFFICIENT_DATA`; (4) three plots and `summary.md` generated.

### Planning Context
- Run dry-run trials directly via the binary, not via run_experiment.sh (to avoid triggering the full 144-trial matrix).
- Invoke analysis via: `micromamba run -n subsampled-tw-rust python research/2026-04-10-subsampled-tw-rust/scripts/analyze_results.py`.
- H6 may produce a real verdict from the m=n trial; all others expected as INSUFFICIENT_DATA.
- The full 144-trial experiment run is out of scope for this group — it is executed by the user after verification.

---

## Traceability

| Requirement | Group |
|-------------|-------|
| P1-DIR | groupA |
| P1-TOOLCHAIN | groupA |
| P1-ENV | groupA |
| P1-SYMLINKS | groupA |
| P1-CARGO | groupA |
| P1-PREFLIGHT | groupA |
| P2-CLI | groupB |
| P2-EXACT | groupB |
| P2-SUBSAMPLE | groupB |
| P2-SANITY | groupB |
| P2-DETERMINISM | groupB |
| P2-JSON | groupB |
| P2-ACCEPT | groupB |
| P3-UTILS | groupC |
| P3-ANALYZE | groupC |
| P3-SHELL | groupC |
| P4-DRYRUN | groupD |
| P4-ACCEPT | groupD |
