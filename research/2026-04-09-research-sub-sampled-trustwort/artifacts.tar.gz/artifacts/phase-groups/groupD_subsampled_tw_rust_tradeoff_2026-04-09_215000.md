# Dry Run Validation (groupD)

## Purpose
Execute a minimal 3-trial subset of the experiment to validate end-to-end pipeline correctness before committing to the full ~144-trial run. The dry run confirms that the binary, orchestration script, and analysis script all interoperate correctly and produce the expected output structure. This group produces no new code — it executes the pipeline and verifies acceptance criteria.

## Dependencies
- groupA (directory scaffold complete)
- groupB (binary implemented and passing sanity acceptance criterion)
- groupC (analysis script and run_experiment.sh implemented)

## Requirements
- **P4-DRYRUN:** Execute exactly 3 trials manually (not via run_experiment.sh to avoid triggering the full 144-trial run): (1) `(n=10K, m=2000, seed=0)` — subsample mode; (2) `(n=10K, m=10000, seed=0)` — subsample mode with m=n, serves as H6 sanity check; (3) `(n=50K, m=2000, seed=0)` — subsample mode testing the n=50K data path. Each trial writes one JSON to `results/raw/`.
- **P4-ACCEPT:** Verify all four dry-run acceptance criteria: (1) all 3 trial JSONs are written successfully with all expected fields present (`n`, `m`, `k`, `seed`, `mode`, `t_exact`, `t_sub`, `abs_delta_t`, `wall_exact_ms`, `wall_sub_ms`, `warmup_exact_ms`, `warmup_sub_ms`, `cpu_model`, `core_count`, `rust_version`, `git_commit`); (2) the m=n trial (n=10K, m=10000) produces `abs_delta_t < 1e-10`; (3) `python scripts/analyze_results.py` runs without error and produces `results/analysis/verdicts.json` with all 6 hypothesis keys (H1–H6); most will have `"verdict": "INSUFFICIENT_DATA"` — H6 may have a real verdict; (4) the three plots (`error_vs_m.png`, `speedup_vs_m.png`, `variance_decay.png`) and `summary.md` are generated (content may be sparse).

## Planning Context
- Run the 3 dry-run trials from the project root using the compiled binary at `target/release/examples/tw_subsample_experiment`.
- The analysis script must be invoked with the `subsampled-tw-rust` conda env: `micromamba run -n subsampled-tw-rust python research/2026-04-10-subsampled-tw-rust/scripts/analyze_results.py`.
- Dry-run expected verdicts: H1 — `INSUFFICIENT_DATA` (1 data point); H2 — `INSUFFICIENT_DATA` (2 m-values, below OLS minimum); H3 — `INSUFFICIENT_DATA` (2 m-values); H4 — `INSUFFICIENT_DATA` or evaluable if speedup computable from 1 exact + 1 subsample; H5 — `INSUFFICIENT_DATA` (1 data point at n=50K); H6 — evaluable from trial (n=10K, m=10000).
- If any acceptance criterion fails, diagnose the root cause and fix before proceeding to the full experiment run. Do not run the full trial matrix until the dry run passes completely.
- The full experiment run (144 trials, ~45 min) is executed separately by the user after this group's acceptance criteria are verified — it is out of scope for this implementation group.
