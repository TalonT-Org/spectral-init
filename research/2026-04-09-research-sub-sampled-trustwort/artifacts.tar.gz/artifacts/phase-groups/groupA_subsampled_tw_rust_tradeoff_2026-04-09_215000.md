# Directory Scaffold, Toolchain, Environment, and Preflight (groupA)

## Purpose
Create the experiment directory tree, pin the Rust toolchain, define the Python conda environment, create data symlinks, register the experiment binary in Cargo.toml, and implement the `--preflight` mode that verifies MERFISH fixtures. This group produces the foundational scaffold that all subsequent groups build on. Nothing else can be implemented until the directory exists and the binary entry point is registered.

## Dependencies
None.

## Requirements
- **P1-DIR:** Create the full experiment directory tree at `research/2026-04-10-subsampled-tw-rust/` including subdirectories `scripts/`, `data/merfish/`, `results/raw/`, `results/analysis/`.
- **P1-TOOLCHAIN:** Create `research/2026-04-10-subsampled-tw-rust/rust-toolchain.toml` pinning `channel = "nightly-2026-03-26"` to match all prior experiment toolchain pins.
- **P1-ENV:** Create `research/2026-04-10-subsampled-tw-rust/environment.yml` with the `subsampled-tw-rust` conda env spec: Python 3.11, numpy 2.2, scipy 1.15, scikit-learn 1.6, matplotlib 3.10.
- **P1-SYMLINKS:** Create symlinks in `data/merfish/` pointing to the four pre-existing MERFISH fixtures at `research/2026-04-05-tw-perf-rerun-clean/data/merfish/`: `merfish_n10k_x.npy`, `merfish_n10k_y.npy`, `merfish_n50k_x.npy`, `merfish_n50k_y.npy`.
- **P1-CARGO:** Add a `[[example]]` entry to `Cargo.toml` registering `tw_subsample_experiment` with `path = "research/2026-04-10-subsampled-tw-rust/scripts/tw_subsample_experiment.rs"` and `required-features = ["cli"]`.
- **P1-PREFLIGHT:** Implement `--preflight` mode in the experiment binary (stub is sufficient — full binary is groupB). The preflight mode: (1) verifies each of the four fixture files exists, (2) loads each `.npy` via `ndarray_npy::read_npy` and checks shape (n10k_x: (10000,50), n10k_y: (10000,2), n50k_x: (50000,50), n50k_y: (50000,2)) and dtype f64, (3) prints `"PREFLIGHT OK"` or `"PREFLIGHT FAILED: {reason}"` and exits.

## Planning Context
- The `cli` feature already exists in `Cargo.toml` (line 24) and provides `ndarray-npy`, `pico-args`, `serde_json`, `libc` — all needed by the binary. No new dependencies required.
- Existing `[[example]]` entries in `Cargo.toml` use paths under `examples/`; the new entry uses a `research/` path following the same pattern.
- MERFISH fixture source path: `/home/talon/projects/spectral-init/research/2026-04-05-tw-perf-rerun-clean/data/merfish/` — confirmed present with all four files.
- `research/2026-04-10-subsampled-tw-rust/` does not yet exist.
- Acceptance criterion: `cargo run --release --features cli --example tw_subsample_experiment -- --preflight --data-dir research/2026-04-10-subsampled-tw-rust/data/merfish` prints `PREFLIGHT OK`.
